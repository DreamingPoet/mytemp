// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "IOBSRequest.h"
#include "OBSClientBPFuncLib.h"

IOBSRequest::IOBSRequest()
{

}

IOBSRequest::~IOBSRequest()
{
	HttpRequest.Reset();
}

bool IOBSRequest::Create()
{
	return Create(TArray<uint8>(), "");
}

bool IOBSRequest::Create(const FString& Content, const FString& ContentType /*= ""*/)
{
	return Create(UOBSClientBPFuncLib::StringToBytes(Content), ContentType);
}

bool IOBSRequest::Create(const TArray<uint8>& Content, const FString& ContentType /*= ""*/)
{
	if (HttpRequest.IsValid())
		HttpRequest.Reset();

	if (URL.IsEmpty())
		return false;

	FHttpModule* Http = &FHttpModule::Get();
	if (!Http || !Http->IsHttpEnabled())
		return false;

	HttpRequest = Http->CreateRequest();
	if (!HttpRequest.IsValid())
		return false;

	switch (Method)
	{
	default:
	case EOBSRequestMethod::GET:
		HttpRequest->SetVerb("GET");
		break;
	case EOBSRequestMethod::POST:
		HttpRequest->SetVerb("POST");
		break;
	case EOBSRequestMethod::PUT:
		HttpRequest->SetVerb("PUT");
		break;
	case EOBSRequestMethod::DELETE:
		HttpRequest->SetVerb("DELETE");
		break;
	case EOBSRequestMethod::HEAD:
		HttpRequest->SetVerb("HEAD");
		break;
	}

	if (QueryString.Num() > 0)
		URL = UOBSClientBPFuncLib::AppendQueryString(URL, QueryString);

	HttpRequest->SetURL(URL);

	if (ContentType != "")
		HttpRequest->SetHeader("Content-Type", ContentType);
	else
		HttpRequest->SetHeader("Content-Type", "");

	if (Headers.Num() > 0)
		for (TPair<FString, FString> Header : Headers)
			if (Header.Key.ToLower() != "content-type")
				HttpRequest->SetHeader(Header.Key, Header.Value);

	if (Content.Num() > 0)
		HttpRequest->SetContent(Content);

	return true;
}

bool IOBSRequest::Process()
{
	return HttpRequest->ProcessRequest();
}

bool IOBSRequest::IsRunning() const
{
	if (!HttpRequest.IsValid())
		return false;

	EHttpRequestStatus::Type Status = HttpRequest->GetStatus();
	return Status == EHttpRequestStatus::Processing;
}

bool IOBSRequest::IsComplete() const
{
	if (!HttpRequest.IsValid())
		return false;

	EHttpRequestStatus::Type Status = HttpRequest->GetStatus();
	return Status == EHttpRequestStatus::Failed || Status == EHttpRequestStatus::Failed_ConnectionError || Status == EHttpRequestStatus::Succeeded;
}

bool IOBSRequest::Send()
{
	if (!Create())
		return false;

	return Process();
}

bool IOBSRequest::Send(const FString& Content, const FString& ContentType /*= ""*/)
{
	if (!Create(Content, ContentType))
		return false;

	return Process();
}

bool IOBSRequest::Send(const TArray<uint8>& Content, const FString& ContentType /*= ""*/)
{
	if (!Create(Content, ContentType))
		return false;

	return Process();
}

void IOBSRequest::Cancel()
{
	if (!HttpRequest.IsValid())
		return;

	if (HttpRequest->GetStatus() == EHttpRequestStatus::Processing)
		HttpRequest->CancelRequest();

	HttpRequest.Reset();
}

void IOBSRequest::Reset()
{
	Method = EOBSRequestMethod::GET;
	URL = FString();

	QueryString = TMap<FString, FString>();
	Headers = TMap<FString, FString>();

	HttpRequest.Reset();
}

float IOBSRequest::GetElapsedTime()
{
	return HttpRequest->GetElapsedTime();
}