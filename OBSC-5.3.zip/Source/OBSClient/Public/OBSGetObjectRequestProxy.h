// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "OBSClientManager.h"
#include "OBSBinaryRequest.h"
#include "OBSGetObjectRequestProxy.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_SevenParams(FOBSGetObjectResponesEvent, const UOBSGetObjectRequestProxy*, OBSObj, const TArray<uint8>&, Response, int32, StatusCode, int32, BytesReceived, float, DataTransPercent, int32, TotalBytes, float, ElapsedTime);

UCLASS(BlueprintType, meta = (HideThen = true))
class OBSCLIENT_API UOBSGetObjectRequestProxy : public UObject
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(BlueprintAssignable, Category = "OBSGetObject Request")
		FOBSGetObjectResponesEvent OnSuccess;

	UPROPERTY(BlueprintAssignable, Category = "OBSGetObject Request")
		FOBSGetObjectResponesEvent OnProgress;

	UPROPERTY(BlueprintAssignable, Category = "OBSGetObject Request")
		FOBSGetObjectResponesEvent OnFailure;

	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", AutoCreateRefTerm = "CanonicalizedHeaders, QueryString", AdvancedDisplay = "CanonicalizedHeaders, QueryString"), Category = "OBS Library")
		static UOBSGetObjectRequestProxy* CreateProxyObject(const FString& BucketName,FString ObjectName, const FString& SavePathAndName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString);
public:
	UFUNCTION(BlueprintCallable, Category = "OBS Library")
		void Cancel() { Http.Cancel(); }

protected:

	FOBSBinaryRequest Http;

	void TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content);
	void TriggerProgress(int32 Sent, int32 Received);
	void RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType);
	
	void TriggerResponseGetObjInfo(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content);
	void RequestPerformGetObjInfo(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TArray<uint8>& Content, const FString& ContentType, const FString& Bucket, const FString& ObjectKey, const TMap<FString, FString>& TmpCanonicalizedHeaders_, const TMap<FString, FString>& TmpQueryString_);

	FString TmpSavePathAndName;
private:

	int32 HttpSent;
	int32 HttpReceived;
	int32 ContentLength;

	FString TmpBucket;
	FString TmpObjectKey;

	TMap<FString, FString> TmpCanonicalizedHeaders;
	TMap<FString, FString> TmpQueryString;
};
