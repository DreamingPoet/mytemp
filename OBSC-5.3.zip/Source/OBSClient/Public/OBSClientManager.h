// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "OBSClientManager.generated.h"

UENUM(BlueprintType)
enum class EOBSRequestMethod : uint8
{
	GET		UMETA(DisplayName = "GET"),
	POST	UMETA(DisplayName = "POST"),
	PUT		UMETA(DisplayName = "PUT"),
	DELETE	UMETA(DisplayName = "DELETE"),
	HEAD	UMETA(DisplayName = "HEAD")
};


UENUM(BlueprintType)
enum class EEndpointStyle :uint8
{
	PathsStyle			UMETA(DisplayName = "PathsStyle"),
	VirtualHostedStyle	UMETA(DisplayName = "VirtualHostedStyle")
};

UENUM(BlueprintType)
enum class EAcl : uint8
{
	PRIVATE	UMETA(DisplayName = "private"),
	PUBLIC_READ	UMETA(DisplayName = "public-read"),
	PUBLIC_READ_WRITE UMETA(DisplayName = "public-read-write"),
	PUBLIC_READ_DELIVERED UMETA(DisplayName = "public-read-delivered"),
	PUBLIC_READ_WRITE_DELIVERED UMETA(DisplayName = "public-read-write-delivered"),
	BUCKET_OWNER_FULL_CONTROL UMETA(DisplayName = "bucket-owner-full-control")
};


USTRUCT(BlueprintType)
struct FRequestHeaders
{
	GENERATED_USTRUCT_BODY()

	FRequestHeaders(){}

	FRequestHeaders(TMap <FString, FString> Headers_)
	{
		Headers = Headers_;
	}

	UPROPERTY(BlueprintReadWrite, Category = "OBSClient Manager")
		TMap <FString, FString> Headers;

};

USTRUCT(BlueprintType)
struct FResponse
{
	GENERATED_USTRUCT_BODY()

	FResponse(){}

	FResponse(const TMap <FString, FString>& Headers_, const TArray <uint8>& Content_, int32 StatusCode_)
	{
		Headers = Headers_;
		Content = Content_;
		StatusCode = StatusCode_;
	}

	UPROPERTY(BlueprintReadWrite, Category = "OBSClient Manager")
		TMap <FString, FString> Headers;

	UPROPERTY(BlueprintReadWrite, Category = "OBSClient Manager")
		TArray <uint8> Content;

	UPROPERTY(BlueprintReadWrite, Category = "OBSClient Manager")
		int32 StatusCode;

};


class FOBSClientManager :public TSharedFromThis<FOBSClientManager>
{
public:

	static TSharedRef<FOBSClientManager> Get()
	{
		if (!OBSClientManagerIns.IsValid())
		{
			OBSClientManagerIns = MakeShareable<FOBSClientManager>(new FOBSClientManager());
		}
		return OBSClientManagerIns->AsShared();
	}


	void Init(const FString& AccessKeyID_, const FString& SecretKey_, const FString& Endpoint_, const EEndpointStyle EndpointStyle_, const FString& ProductName_, bool UseHttps_, bool SignWithObjectKeyUrlEncoded_);

	FString GetAccessKeyID() { return AccessKeyID; }
	FString GetSecretKey() { return SecretKey; }
	FString GetEndpoint() { return Endpoint; }
	FString GetHttpProtocol() { return UseHttps ? "https://" : "http://"; }
	FString GetProductName() { return ProductName; }
	bool IsSignWithObjectKeyUrlEncoded() { return SignWithObjectKeyUrlEncoded; }
	EEndpointStyle GetEndpointStyle() { return EndpointStyle; }


protected:

private:

	static TSharedPtr<FOBSClientManager> OBSClientManagerIns;
	FString AccessKeyID;
	FString SecretKey;
	FString Endpoint;
	EEndpointStyle EndpointStyle = EEndpointStyle::PathsStyle;
	FString ProductName;
	bool UseHttps;
	bool SignWithObjectKeyUrlEncoded;
};