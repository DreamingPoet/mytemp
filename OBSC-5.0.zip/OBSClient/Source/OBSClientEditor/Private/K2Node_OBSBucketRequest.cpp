// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "K2Node_OBSBucketRequest.h"
#include "OBSBucketRequestProxy.h"

#define LOCTEXT_NAMESPACE "K2Node_OBS"

UK2Node_OBSBucketRequest::UK2Node_OBSBucketRequest(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UOBSBucketRequestProxy, CreateProxyObject);
	ProxyFactoryClass = UOBSBucketRequestProxy::StaticClass();
	ProxyClass = UOBSBucketRequestProxy::StaticClass();
}

FText UK2Node_OBSBucketRequest::GetTooltipText() const
{
	return LOCTEXT("K2Node_OBSBucketRequest_Tooltip", "Bucket operations via RESTful request");
}
FText UK2Node_OBSBucketRequest::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("OBSBucketRequest", "OBS Bucket Request");
}
void UK2Node_OBSBucketRequest::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
	Super::GetPinHoverText(Pin, HoverTextOut);

	static FName NAME_OnSuccess = FName(TEXT("OnSuccess"));
	static FName NAME_OnProgress = FName(TEXT("OnProgress"));
	static FName NAME_OnFailure = FName(TEXT("OnFailure"));

	if (Pin.PinName == NAME_OnSuccess)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSBucketRequest_OnSuccess_Tooltip", "Called when the OBS request successfully completed, StatusCode == 200.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnProgress)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSBucketRequest_OnProgress_Tooltip", "Called when the OBS request on progress.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnFailure)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSBucketRequest_OnFailure_Tooltip", "Called when the OBS request failed.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
}

FText UK2Node_OBSBucketRequest::GetMenuCategory() const
{
	return FText::FromString("OBSClient|Bucket");
}

#undef LOCTEXT_NAMESPACE
