// Copyright 2023 Dreamingpoet All Rights Reserved.
#include "OBSPutObjectRequestProxy.h"
#include "OBSClientBPFuncLib.h"
#include "Misc/Paths.h"

UOBSPutObjectRequestProxy::UOBSPutObjectRequestProxy(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	HttpSent = 0;
	HttpReceived = 0;
}

void UOBSPutObjectRequestProxy::TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content)
{
	if (StatusCode > 0)
		OnSuccess.Broadcast(this, Content, StatusCode, HttpSent, HttpSent * 1.f / ContentLength, ContentLength, Http.GetElapsedTime());
	else
		OnFailure.Broadcast(this, Content, 0, HttpSent, HttpSent * 1.f / ContentLength, ContentLength, 0.f);

	HttpSent = 0;
	HttpReceived = 0;

	Http.Reset();
}

void UOBSPutObjectRequestProxy::TriggerProgress(int32 Sent, int32 Received)
{
	HttpSent = Sent;
	OnProgress.Broadcast(this, TArray<uint8>(), 0, HttpSent, HttpSent * 1.f / ContentLength, ContentLength, Http.GetElapsedTime());
}

UOBSPutObjectRequestProxy* UOBSPutObjectRequestProxy::CreateProxyObject(const FString& BucketName, const FString& FilePath, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, FString ObjectName, const FString& ContentType, bool UseMD5)
{
		TArray<uint8> Content;
		FFileHelper::LoadFileToArray(Content, *FilePath);
		TMap<FString, FString> Headers;

		EOBSRequestMethod RequestMethod = EOBSRequestMethod::PUT;

		ObjectName = ObjectName == "" ?  FPaths::GetCleanFilename(FilePath) : ObjectName;

		FString ObjectNameUrlEncoded = FPlatformHttp::UrlEncode(ObjectName);

		UOBSClientBPFuncLib::CreateHeader(
			FOBSClientManager::Get()->GetAccessKeyID(),
			FOBSClientManager::Get()->GetSecretKey(),
			UOBSClientBPFuncLib::RequestMethodToString(RequestMethod),
			UseMD5,
			Content,
			ContentType,
			UOBSClientBPFuncLib::GetDateUtcNow_GMT(),
			CanonicalizedHeaders,
			"/" + BucketName / (FOBSClientManager::Get()->IsSignWithObjectKeyUrlEncoded() ? ObjectNameUrlEncoded : ObjectName),
			Headers,
			FOBSClientManager::Get()->GetProductName()
		);


		FString URL = "";
		if (FOBSClientManager::Get()->GetEndpointStyle() == EEndpointStyle::PathsStyle)
			URL = FOBSClientManager::Get()->GetEndpoint() / BucketName / ObjectNameUrlEncoded;
		else
			URL = FOBSClientManager::Get()->GetHttpProtocol() + BucketName + "." + FOBSClientManager::Get()->GetEndpoint() / ObjectNameUrlEncoded;

		UOBSPutObjectRequestProxy* Proxy = NewObject<UOBSPutObjectRequestProxy>();
		Proxy->SetFlags(RF_StrongRefOnFrame);

		Proxy->RequestPerform(
			RequestMethod,
			URL,
			Headers,
			QueryString,
			Content,
			ContentType
		);
		return Proxy;
}

void UOBSPutObjectRequestProxy::RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType)
{
	ContentLength = Content.Num();
	Http.Method = Method;
	Http.URL = URL;
	Http.QueryString = QueryString;
	Http.Headers = Headers;
	Http.OnResponse.BindUObject(this, &UOBSPutObjectRequestProxy::TriggerResponse);
	Http.OnProgress.BindUObject(this, &UOBSPutObjectRequestProxy::TriggerProgress);
	Http.Send(Content, ContentType);
}
