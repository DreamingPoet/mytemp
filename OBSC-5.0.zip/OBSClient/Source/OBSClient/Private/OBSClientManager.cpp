// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "OBSClientManager.h"

TSharedPtr<FOBSClientManager>FOBSClientManager::OBSClientManagerIns;

void FOBSClientManager::Init(const FString& AccessKeyID_, const FString& SecretKey_, const FString& Endpoint_, const EEndpointStyle EndpointStyle_, bool UseHttps_)
{
	AccessKeyID = AccessKeyID_;
	SecretKey = SecretKey_;
	Endpoint = Endpoint_;
	EndpointStyle = EndpointStyle_;
	UseHttps = UseHttps_;
}
