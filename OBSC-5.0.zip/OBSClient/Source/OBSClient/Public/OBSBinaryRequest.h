// Copyright 2023 Dreamingpoet All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "IOBSRequest.h"
#include "Http.h"
#include "OBSClientManager.h"
// #include "OBSBinaryRequest.generated.h"

struct OBSCLIENT_API FOBSBinaryRequest : public IOBSRequest
{
	FOBSBinaryResponse OnResponse;
	FOBSProgress       OnProgress;


protected:

	virtual bool Process() override;
};