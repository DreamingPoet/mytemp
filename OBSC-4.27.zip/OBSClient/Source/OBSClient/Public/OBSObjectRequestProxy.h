// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "OBSClientManager.h"
#include "OBSBinaryRequest.h"
#include "OBSObjectRequestProxy.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOBSObjectResponesEvent, const UOBSObjectRequestProxy*, OBSObj, const FResponse&, Response);

UCLASS(BlueprintType, meta = (HideThen = true))
class OBSCLIENT_API UOBSObjectRequestProxy : public UObject
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(BlueprintAssignable, Category = "OBSObject Request")
		FOBSObjectResponesEvent OnSuccess;

	UPROPERTY(BlueprintAssignable, Category = "OBSObject Request")
		FOBSObjectResponesEvent OnProgress;

	UPROPERTY(BlueprintAssignable, Category = "OBSObject Request")
		FOBSObjectResponesEvent OnFailure;

	/**
	 * OBSObject
	 *
	 * @param BucketName BucketName
	 * @param ObjectName Full ObjectName, include all paths except for bucket example: subfolder/filename.txt
	 * @param Content Object/file binary content
	 * 
	 * @return OBSObjectRequestProxy UObject
	 */
	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", AutoCreateRefTerm = "CanonicalizedHeaders, Content, QueryString", AdvancedDisplay = "CanonicalizedHeaders, QueryString, Content, ContentType, UseMD5"), Category = "OBS Library")
		static UOBSObjectRequestProxy* CreateProxyObject(EOBSRequestMethod Method, const FString& BucketName, const FString& ObjectName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType, bool UseMD5);
public:
	UFUNCTION(BlueprintCallable, Category = "OBS Library")
	void Cancel(){ Http.Cancel();}

protected:

	FOBSBinaryRequest Http;

	void TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content);
	void TriggerProgress(int32 Sent, int32 Received);
	void RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType);

private:

	int32 HttpSent;
	int32 HttpReceived;
	int32 ContentLength;
};
