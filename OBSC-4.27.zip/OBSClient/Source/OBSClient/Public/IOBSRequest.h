// Copyright 2023 Dreamingpoet All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "OBSClientManager.h"

typedef TMap<FString, FString> FOBSRequestHeaders;

DECLARE_DELEGATE_TwoParams(FOBSProgress, int32 /*Sent*/, int32 /*Received*/);

DECLARE_DELEGATE_ThreeParams(FOBSBinaryResponse, int32 /*StatusCode*/, const FOBSRequestHeaders& /*Headers*/, const TArray<uint8>& /*Content*/);

struct OBSCLIENT_API IOBSRequest
{
public:

	IOBSRequest();
	virtual ~IOBSRequest();

	EOBSRequestMethod Method = EOBSRequestMethod::GET;
	FString URL;

	TMap<FString, FString> Headers;
	TMap<FString, FString> QueryString;

protected:

	TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> HttpRequest;

	virtual bool Create();
	virtual bool Create(const FString& Content, const FString& ContentType = "");
	virtual bool Create(const TArray<uint8>& Content, const FString& ContentType = "");

	virtual bool Process();

public:

	bool IsRunning() const;
	bool IsComplete() const;

	bool Send();
	bool Send(const FString& Content, const FString& ContentType = "");
	bool Send(const TArray<uint8>& Content, const FString& ContentType = "");

	void Cancel();
	void Reset();
	float GetElapsedTime();
};
