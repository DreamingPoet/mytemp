// Copyright 2023 Dreamingpoet All Rights Reserved.
#include "OBSBucketRequestProxy.h"
#include "OBSClientBPFuncLib.h"

UOBSBucketRequestProxy::UOBSBucketRequestProxy(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	HttpSent = 0;
	HttpReceived = 0;
}

void UOBSBucketRequestProxy::TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content)
{
	if (StatusCode > 0)
		OnSuccess.Broadcast(FResponse(Headers, Content, StatusCode));
	else
		OnFailure.Broadcast(FResponse(Headers, Content, StatusCode));

	HttpSent = 0;
	HttpReceived = 0;

	Http.Reset();
}

void UOBSBucketRequestProxy::TriggerProgress(int32 Sent, int32 Received)
{
	HttpSent = Sent;
	OnProgress.Broadcast(FResponse());
}

UOBSBucketRequestProxy* UOBSBucketRequestProxy::CreateProxyObject(EOBSRequestMethod Method, const FString& BucketName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType, bool UseMD5)
{

	// 如果既有BucketName也有ObjectName，则则CanonicalizedResource格式为 / BucketName / ObjectName
	// 如果仅有BucketName而没有ObjectName，则CanonicalizedResource格式为 / BucketName / 
	// 如果既没有BucketName也没有ObjectName，则CanonicalizedResource为正斜线（ / ）
	FString CanonicalizedResource = BucketName.IsEmpty() ? "/" : "/" + BucketName + "/";

	TMap<FString, FString> Headers;
	UOBSClientBPFuncLib::CreateHeader(
		FOBSClientManager::Get()->GetAccessKeyID(),
		FOBSClientManager::Get()->GetSecretKey(),
		UOBSClientBPFuncLib::RequestMethodToString(Method),
		UseMD5,
		Content,
		ContentType,
		UOBSClientBPFuncLib::GetDateUtcNow_GMT(),
		CanonicalizedHeaders,
		CanonicalizedResource,
		Headers,
		FOBSClientManager::Get()->GetProductName()
	);

	FString URL;
	if (FOBSClientManager::Get()->GetEndpointStyle() == EEndpointStyle::PathsStyle)
		// PathsStyle 模式下,资源的最后面必须加 / 
		URL = FOBSClientManager::Get()->GetEndpoint() / (BucketName.IsEmpty() ? "" : BucketName + "/");
	else
		URL = FOBSClientManager::Get()->GetHttpProtocol() + (BucketName.IsEmpty() ? "" : BucketName + ".") + FOBSClientManager::Get()->GetEndpoint();

	UOBSBucketRequestProxy* Proxy = NewObject<UOBSBucketRequestProxy>();
	Proxy->SetFlags(RF_StrongRefOnFrame);

	Proxy->RequestPerform(
		Method,
		URL,
		Headers,
		QueryString,
		Content,
		ContentType
	);
	return Proxy;
}

void UOBSBucketRequestProxy::RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType)
{
	ContentLength = Content.Num();
	Http.Method = Method;
	Http.URL = URL;
	Http.QueryString = QueryString;
	Http.Headers = Headers;
	Http.OnResponse.BindUObject(this, &UOBSBucketRequestProxy::TriggerResponse);
	Http.OnProgress.BindUObject(this, &UOBSBucketRequestProxy::TriggerProgress);
	Http.Send(Content, ContentType);
}
