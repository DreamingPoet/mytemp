// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "OBSClientBPFuncLib.h"
#include "Misc/Base64.h"
#include "Http.h"
#include <iostream>

 void UOBSClientBPFuncLib::OBSClientInit(const FString& AccessKeyID, const FString& SecretKey, const FString& Endpoint, EEndpointStyle EndpointStyle, const FString& ProductName/* AWS */, bool UseHttps/* true */, bool SignWithObjectKeyUrlEncoded/* false */)
 {
 	FOBSClientManager::Get()->Init(AccessKeyID, SecretKey, Endpoint, EndpointStyle, ProductName, UseHttps, SignWithObjectKeyUrlEncoded);
 }


#ifdef WITH_EDITOR
#pragma optimize("", off)
#endif

void UOBSClientBPFuncLib::CreateHeader(const FString& AccessKey, const FString& SecretKey,
	const FString& HTTPVerb, bool UseMD5, const TArray<uint8>& Content, const FString& ContentType,
	const FString& Date, const TMap<FString, FString>& CanonicalizedHeaders,
	const FString& CanonicalizedResource, TMap<FString, FString>& OutHeader, const FString& ProductName)
{
	FString CanonicalizedHeadersString = "";
	for (auto i: CanonicalizedHeaders)
	{
		OutHeader.Add(i.Key.ToLower(), i.Value);
		CanonicalizedHeadersString += (i.Key.ToLower() + ":" + i.Value + "\n");
	}

	FString ContentMD5 = "";
	if(UseMD5)
	{
		ContentMD5 = FMD5::HashBytes(Content.GetData(), Content.Num());
	}

	FString StringToSign =
		HTTPVerb + "\n" + 
		ContentMD5 + "\n" +
		ContentType + "\n" +
		Date + "\n" + CanonicalizedHeadersString + CanonicalizedResource;

	std::string cstring(TCHAR_TO_UTF8(*StringToSign));//FString 转 C++ string
	int32 len = cstring.length();

	TArray<uint8> sign;
	sign.AddUninitialized(20);
	FSHA1::HMACBuffer(TCHAR_TO_UTF8(*SecretKey), SecretKey.Len(), TCHAR_TO_UTF8(*StringToSign), len, sign.GetData());

	FString Authorization = ProductName + " " + AccessKey + ":" + FBase64::Encode(sign);

	OutHeader.Add("Authorization", Authorization);
	OutHeader.Add("Date", Date);
	if (ContentMD5 != "") OutHeader.Add("Content-MD5", ContentMD5);
	if (ContentType != "") OutHeader.Add("Content-Type", ContentType);
}



FString UOBSClientBPFuncLib::GetDateUtcNow_GMT()
{
	return FDateTime::UtcNow().ToHttpDate();
}

FString UOBSClientBPFuncLib::RequestMethodToString(EOBSRequestMethod Method)
{
	switch (Method)
	{
	case EOBSRequestMethod::GET:
		return "GET";
	case EOBSRequestMethod::PUT:
		return "PUT";
	case EOBSRequestMethod::DELETE:
		return "DELETE";
	case EOBSRequestMethod::HEAD:
		return "HEAD";
	}
	return "GET";
}

EOBSRequestMethod UOBSClientBPFuncLib::StringToRequestMethod(const FString& MethodStr)
{
	FString MethodString = MethodStr.ToUpper();
	if (MethodString == "GET") return EOBSRequestMethod::GET;
	if (MethodString == "PUT") return EOBSRequestMethod::PUT;
	if (MethodString == "DELETE") return EOBSRequestMethod::DELETE;
	if (MethodString == "HEAD") return EOBSRequestMethod::HEAD;
	return EOBSRequestMethod::GET;
}

FString UOBSClientBPFuncLib::BytesToString(const TArray<uint8>& Data)
{
	if (Data.Num() > 0 && Data.Last() == 0) return UTF8_TO_TCHAR(Data.GetData());

	TArray<uint8> ZeroTerminated(Data);
	ZeroTerminated.Add(0);
	return UTF8_TO_TCHAR(ZeroTerminated.GetData());
}
TArray<uint8> UOBSClientBPFuncLib::StringToBytes(const FString& Data)
{
	TArray<uint8> Payload;

	FTCHARToUTF8 Converter(*Data);
	Payload.SetNum(Converter.Length());
	FMemory::Memcpy(Payload.GetData(), (uint8*)(ANSICHAR*)Converter.Get(), Payload.Num());

	return Payload;
}

FString UOBSClientBPFuncLib::AppendQueryString(const FString& URL, const TMap<FString, FString>& QueryString)
{
	if (QueryString.Num() <= 0) return URL;
		
	FString LeftString;
	FString RightString;
	if (!URL.Contains("?") || !URL.Split("?", &LeftString, &RightString))
		LeftString = URL;

	for (TPair<FString, FString> Param : QueryString)
	{
		if (Param.Key.IsEmpty())
			continue;

		if (!RightString.IsEmpty())
			RightString += "&";

		RightString += FPlatformHttp::UrlEncode(Param.Key);
		// support: xxx.com?replication&comp=add	
		// also support: xxx.com?replication=false&comp=add
		if(!Param.Value.IsEmpty())
			RightString += "=";

		RightString += FPlatformHttp::UrlEncode(Param.Value);
	}

	return LeftString + "?" + RightString;
}

FString UOBSClientBPFuncLib::UrlEncode(const FString& input)
{
	return FGenericPlatformHttp::UrlEncode(input);
}

FString UOBSClientBPFuncLib::AclToString(const EAcl& Key)
{
	switch (Key)
	{
	case EAcl::PRIVATE:
		return "private";
	case EAcl::PUBLIC_READ:
		return "public-read";
	case EAcl::PUBLIC_READ_WRITE:
		return "public-read-write";
	case EAcl::PUBLIC_READ_DELIVERED:
		return "public-read-delivered";
	case EAcl::PUBLIC_READ_WRITE_DELIVERED:
		return "public-read-write-delivered";
	case EAcl::BUCKET_OWNER_FULL_CONTROL:
		return "bucket-owner-full-control";
	}
	return "private";
}

EAcl UOBSClientBPFuncLib::StringToAcl(const FString& AclString)
{
	FString AclString_ = AclString.ToLower();
	if (AclString_ == "private") return EAcl::PRIVATE;
	if (AclString_ == "public-read") return EAcl::PUBLIC_READ;
	if (AclString_ == "public-read-write") return EAcl::PUBLIC_READ_WRITE;
	if (AclString_ == "public-read-delivered") return EAcl::PUBLIC_READ_DELIVERED;
	if (AclString_ == "public-read-write-delivered") return EAcl::PUBLIC_READ_WRITE_DELIVERED;
	if (AclString_ == "bucket-owner-full-control") return EAcl::BUCKET_OWNER_FULL_CONTROL;
	return EAcl::PRIVATE;
}

FString UOBSClientBPFuncLib::ObjectKeyUrlEncode(const FString& In)
{
	TArray<FString> out;
	In.ParseIntoArray(out, TEXT("/"));

	FString out_res;
	for(auto ite = out.CreateIterator(); ite; ++ite)
	{
		out_res += ite + 1 ? FGenericPlatformHttp::UrlEncode(*ite) + "/" : FGenericPlatformHttp::UrlEncode(*ite);
	}
	return out_res;
}

FString UOBSClientBPFuncLib::ObjectKeyUrlDecode(const FString& In)
{
	
	return FString();
}



#ifdef WITH_EDITOR
#pragma optimize("", on)
#endif