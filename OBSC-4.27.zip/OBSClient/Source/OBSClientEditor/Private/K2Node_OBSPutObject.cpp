// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "K2Node_OBSPutObject.h"
#include "OBSPutObjectRequestProxy.h"

#define LOCTEXT_NAMESPACE "K2Node_OBS"

UK2Node_OBSPutObject::UK2Node_OBSPutObject(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UOBSPutObjectRequestProxy, CreateProxyObject);
	ProxyFactoryClass = UOBSPutObjectRequestProxy::StaticClass();
	ProxyClass = UOBSPutObjectRequestProxy::StaticClass();
}

FText UK2Node_OBSPutObject::GetTooltipText() const
{
	return LOCTEXT("K2Node_OBSPutObject_Tooltip", "Upload a file to OBSServer use RESTful PUT");
}
FText UK2Node_OBSPutObject::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("OBSPutObject", "OBS Put Object");
}
void UK2Node_OBSPutObject::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
	Super::GetPinHoverText(Pin, HoverTextOut);

	static FName NAME_OnSuccess = FName(TEXT("OnSuccess"));
	static FName NAME_OnProgress = FName(TEXT("OnProgress"));
	static FName NAME_OnFailure = FName(TEXT("OnFailure"));

	if (Pin.PinName == NAME_OnSuccess)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSPutObject_OnSuccess_Tooltip", "Called when the OBS request successfully completed.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnProgress)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSPutObject_OnProgress_Tooltip", "Called when the OBS request on progress.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnFailure)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSPutObject_OnFailure_Tooltip", "Called when the OBS request failed.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
}

FText UK2Node_OBSPutObject::GetMenuCategory() const
{
	return FText::FromString("OBSClient|Object");
}

#undef LOCTEXT_NAMESPACE
