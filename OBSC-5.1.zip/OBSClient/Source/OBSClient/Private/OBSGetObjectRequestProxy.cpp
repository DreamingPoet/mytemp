﻿// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "OBSGetObjectRequestProxy.h"
#include "OBSClientBPFuncLib.h"
#include "Misc/FileHelper.h"

UOBSGetObjectRequestProxy::UOBSGetObjectRequestProxy(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	HttpSent = 0;
	HttpReceived = 0;
}

void UOBSGetObjectRequestProxy::TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers,  const TArray<uint8>& Respones)
{
	if (StatusCode > 0)
	{
		FFileHelper::SaveArrayToFile(Respones ,*TmpSavePathAndName);
		OnSuccess.Broadcast(this, Respones, StatusCode, HttpReceived, HttpReceived * 1.f / ContentLength, ContentLength, Http.GetElapsedTime());
	}
	else
		OnFailure.Broadcast(this, TArray<uint8>(), 0, HttpReceived, HttpReceived * 1.f / ContentLength, ContentLength, 0.f );

	HttpSent = 0;
	HttpReceived = 0;

	Http.Reset();
}

void UOBSGetObjectRequestProxy::TriggerProgress(int32 Sent, int32 Received)
{
	HttpSent = Sent;
	HttpReceived = Received;

	OnProgress.Broadcast(this, TArray<uint8>(), 0, HttpReceived, HttpReceived * 1.f / ContentLength, ContentLength, Http.GetElapsedTime());
}

UOBSGetObjectRequestProxy* UOBSGetObjectRequestProxy::CreateProxyObject(const FString& BucketName,FString ObjectName, const FString& SavePathAndName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString)
{
	TArray<uint8> Content;
	TMap<FString, FString> Headers;
	EOBSRequestMethod RequestMethod = EOBSRequestMethod::HEAD;

	FString ObjectNameUrlEncoded = FPlatformHttp::UrlEncode(ObjectName);

	UOBSClientBPFuncLib::CreateHeader(
		FOBSClientManager::Get()->GetAccessKeyID(),
		FOBSClientManager::Get()->GetSecretKey(),
		UOBSClientBPFuncLib::RequestMethodToString(RequestMethod),
		false,
		Content,
		"",
		UOBSClientBPFuncLib::GetDateUtcNow_GMT(),
		CanonicalizedHeaders,
		"/" + BucketName / (FOBSClientManager::Get()->IsSignWithObjectKeyUrlEncoded() ? ObjectNameUrlEncoded : ObjectName),
		Headers,
		FOBSClientManager::Get()->GetProductName()
	);

	FString URL = "";
	if (FOBSClientManager::Get()->GetEndpointStyle() == EEndpointStyle::PathsStyle)
		URL = FOBSClientManager::Get()->GetEndpoint() / BucketName / ObjectNameUrlEncoded;
	else
		URL = FOBSClientManager::Get()->GetHttpProtocol() + BucketName + "." + FOBSClientManager::Get()->GetEndpoint() / ObjectNameUrlEncoded;


	UOBSGetObjectRequestProxy* Proxy = NewObject<UOBSGetObjectRequestProxy>();
	Proxy->SetFlags(RF_StrongRefOnFrame);
	Proxy->TmpSavePathAndName = SavePathAndName;

	Proxy->RequestPerformGetObjInfo(
		RequestMethod,
		URL,
		Headers,
		Content,
		"",
		BucketName,
		ObjectName,
		CanonicalizedHeaders,
		QueryString
		
	);
	return Proxy;
}

void UOBSGetObjectRequestProxy::TriggerResponseGetObjInfo(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content)
{
	Http.OnResponse.Unbind();
	HttpSent = 0;
	HttpReceived = 0;
	Http.Reset();

	if (StatusCode > 0)
	{	
		auto len = Headers.Find("Content-Length");
		if(len != nullptr)
			ContentLength = FCString::Atoi(**len);

		TArray<uint8> Content_;
		TMap<FString, FString> Headers_;

		FString ObjectNameUrlEncoded = FPlatformHttp::UrlEncode(TmpObjectKey);

		EOBSRequestMethod RequestMethod = EOBSRequestMethod::GET;

		UOBSClientBPFuncLib::CreateHeader(
			FOBSClientManager::Get()->GetAccessKeyID(),
			FOBSClientManager::Get()->GetSecretKey(),
			UOBSClientBPFuncLib::RequestMethodToString(RequestMethod),
			false,
			Content_,
			"",
			UOBSClientBPFuncLib::GetDateUtcNow_GMT(),
			TmpCanonicalizedHeaders,
			"/" + TmpBucket / (FOBSClientManager::Get()->IsSignWithObjectKeyUrlEncoded() ? ObjectNameUrlEncoded : TmpObjectKey),
			Headers_,
			FOBSClientManager::Get()->GetProductName()
		);
		FString URL = "";
		if (FOBSClientManager::Get()->GetEndpointStyle() == EEndpointStyle::PathsStyle)
			URL = FOBSClientManager::Get()->GetEndpoint() / TmpBucket / ObjectNameUrlEncoded;
		else
			URL = FOBSClientManager::Get()->GetHttpProtocol() + TmpBucket + "." + FOBSClientManager::Get()->GetEndpoint() / ObjectNameUrlEncoded;

		this->RequestPerform(
			RequestMethod,
			URL,
			Headers_,
			TmpQueryString,
			Content_,
			""
		);
	}
	else // 查询文件信息失败!
	{
		OnFailure.Broadcast(this, TArray<uint8>(), 0, 0, 0, 0, 0.f);
	}

}

void UOBSGetObjectRequestProxy::RequestPerformGetObjInfo(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TArray<uint8>& Content, const FString& ContentType, const FString& Bucket, const FString& ObjectKey, const TMap<FString, FString>& TmpCanonicalizedHeaders_, const TMap<FString, FString>& TmpQueryString_)
{
	TmpBucket = Bucket;
	TmpObjectKey = ObjectKey;
	TmpCanonicalizedHeaders = TmpCanonicalizedHeaders_;
	TmpQueryString = TmpQueryString_;

	Http.Method = Method;
	Http.URL = URL;
	Http.Headers = Headers;
	Http.OnResponse.BindUObject(this, &UOBSGetObjectRequestProxy::TriggerResponseGetObjInfo);
	Http.Send(Content, ContentType);
}

void UOBSGetObjectRequestProxy::RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType)
{
	Http.Method = Method;
	Http.URL = URL;
	Http.Headers = Headers;
	Http.OnResponse.BindUObject(this, &UOBSGetObjectRequestProxy::TriggerResponse);
	Http.OnProgress.BindUObject(this, &UOBSGetObjectRequestProxy::TriggerProgress);
	Http.Send(Content, ContentType);
}

