// Copyright 2023 Dreamingpoet All Rights Reserved.
#include "OBSObjectRequestProxy.h"
#include "OBSClientBPFuncLib.h"

UOBSObjectRequestProxy::UOBSObjectRequestProxy(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	HttpSent = 0;
	HttpReceived = 0;
}

void UOBSObjectRequestProxy::TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content)
{
	if (StatusCode > 0)
		OnSuccess.Broadcast(this, FResponse(Headers, Content, StatusCode));
	else
		OnFailure.Broadcast(this, FResponse());

	HttpSent = 0;
	HttpReceived = 0;

	Http.Reset();
}

void UOBSObjectRequestProxy::TriggerProgress(int32 Sent, int32 Received)
{
	HttpSent = Sent;
	OnProgress.Broadcast(this, FResponse());
}

UOBSObjectRequestProxy* UOBSObjectRequestProxy::CreateProxyObject(EOBSRequestMethod Method, const FString& BucketName, const FString& ObjectName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType, bool UseMD5)
{
	
	TMap<FString, FString> Headers;
	UOBSClientBPFuncLib::CreateHeader(
		FOBSClientManager::Get()->GetAccessKeyID(),
		FOBSClientManager::Get()->GetSecretKey(),
		UOBSClientBPFuncLib::RequestMethodToString(Method),
		UseMD5,
		Content,
		ContentType,
		UOBSClientBPFuncLib::GetDateUtcNow_GMT(),
		CanonicalizedHeaders,
		"/" + BucketName / ObjectName,
		Headers
	);

	FString URL = "";
	if (FOBSClientManager::Get()->GetEndpointStyle() == EEndpointStyle::PathsStyle)
		URL = FOBSClientManager::Get()->GetEndpoint() / BucketName / ObjectName;
	else
		URL = FOBSClientManager::Get()->GetHttpProtocol() + BucketName + "." + FOBSClientManager::Get()->GetEndpoint() / ObjectName;


	UOBSObjectRequestProxy* Proxy = NewObject<UOBSObjectRequestProxy>();
	Proxy->SetFlags(RF_StrongRefOnFrame);

	Proxy->RequestPerform(
	Method,
	URL,
	Headers, 
	QueryString,
	Content,
	ContentType
	);
	return Proxy;
}

void UOBSObjectRequestProxy::RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType)
{
	ContentLength = Content.Num();
	Http.Method = Method;
	Http.URL = URL;
	Http.QueryString = QueryString;
	Http.Headers = Headers;
	Http.OnResponse.BindUObject(this, &UOBSObjectRequestProxy::TriggerResponse);
	Http.OnProgress.BindUObject(this, &UOBSObjectRequestProxy::TriggerProgress);
	Http.Send(Content, ContentType);
}
