// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "OBSClientManager.h"
#include "OBSClientBPFuncLib.generated.h"


/**
 *
 */
UCLASS()
class OBSCLIENT_API UOBSClientBPFuncLib : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	/**
	 * Initiate the OBS client parameters.
	 * @param AccessKeyID
	 * @param SecretKey
	 * @param Endpoint If EndpointStyle is PathsStyle Endpoint will be like: http://127.0.0.1:9000/xxx/ or https://play.min.io/xxx/, and VirtualHostedStyle Endpoint will be like: oss-cn-beijing.aliyuncs.com
	 * @param EndpointStyle
	 * @param UseHttps If true we use https://oss-cn-beijing.aliyuncs.com else we use http://oss-cn-beijing.aliyuncs.com, only effect VirtualHostedStyle.
	 */
	UFUNCTION(BlueprintCallable, meta=(AdvancedDisplay = "UseHttps"), Category = "OBSClient")
		static void OBSClientInit(const FString& AccessKeyID, const FString& SecretKey, const FString& Endpoint, EEndpointStyle EndpointStyle, bool UseHttps = true);
	
	// CreateRequestHeader
	static void CreateHeader(const FString& AccessKey, const FString& SecretKey, const FString& HTTPVerb, bool UseMD5, const TArray<uint8>& Content, const FString& ContentType, const FString& Date, const TMap<FString, FString>& CanonicalizedHeaders, const FString& CanonicalizedResource, TMap<FString, FString>& OutHeader);

	static FString GetDateUtcNow_GMT();

public:

	// =========== data convert =========== 

	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static FString RequestMethodToString(EOBSRequestMethod Method);
	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static EOBSRequestMethod StringToRequestMethod(const FString& MethodStr);

	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static FString BytesToString(const TArray<uint8>& Data);
	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static TArray<uint8> StringToBytes(const FString& Data);

	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static FString AppendQueryString(const FString& URL, const TMap<FString, FString>& QueryString);


	UFUNCTION(BlueprintPure, Category = "OBSClient Util")	
		static FString UrlEncode(const FString& input);


	UFUNCTION(BlueprintPure, Category = "OBSClient Util")
		static FString GetHeader(const FRequestHeaders& Headers, const FString& Key)
	{
		FString result;
		result = *Headers.Headers.Find(Key);
		return result;
	}

	UFUNCTION(BlueprintPure, meta = (DisplayName = "AclToString", CompactNodeTitle = "->", BlueprintAutocast), Category = "OBSClient Util")
	static FString AclToString(const EAcl& Key);

	UFUNCTION(BlueprintPure, meta = (DisplayName = "StringToAcl", CompactNodeTitle = "->", BlueprintAutocast), Category = "OBSClient Util")
	static EAcl StringToAcl(const FString& AclString);


};
