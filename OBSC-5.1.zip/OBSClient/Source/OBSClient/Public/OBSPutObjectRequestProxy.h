// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "OBSClientManager.h"
#include "OBSBinaryRequest.h"
#include "OBSPutObjectRequestProxy.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_SevenParams(FOBSPutObjectResponesEvent, const UOBSPutObjectRequestProxy*, OBSObj, const TArray<uint8>&, Response, int32, StatusCode, int32, BytesSent, float, DataTransPercent, int32, TotalBytes, float, ElapsedTime);

UCLASS(BlueprintType, meta = (HideThen = true))
class OBSCLIENT_API UOBSPutObjectRequestProxy : public UObject
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(BlueprintAssignable, Category = "OBSPutObject Request")
		FOBSPutObjectResponesEvent OnSuccess;

	UPROPERTY(BlueprintAssignable, Category = "OBSPutObject Request")
		FOBSPutObjectResponesEvent OnProgress;

	UPROPERTY(BlueprintAssignable, Category = "OBSPutObject Request")
		FOBSPutObjectResponesEvent OnFailure;

	/**
	 * OBSPutObject
	 *
	 * @param BucketName BucketName
	 * @param FilePath Absolute file path. example: D:/folder/file.text
	 * @param ObjectName If this left empty, clean file name will be used as uploaded object name, exmple: file.text
	 * 
	 * @return OBSPutObjectRequestProxy UObject
	 */
	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", AutoCreateRefTerm = "CanonicalizedHeaders, QueryString", AdvancedDisplay = "CanonicalizedHeaders, QueryString, ContentType, ObjectName, UseMD5"), Category = "OBS Library")
		static UOBSPutObjectRequestProxy* CreateProxyObject(const FString& BucketName, const FString& FilePath, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, FString ObjectName, const FString& ContentType, bool UseMD5);
public:
	UFUNCTION(BlueprintCallable, Category = "OBS Library")
	void Cancel(){ Http.Cancel();}

protected:

	FOBSBinaryRequest Http;

	void TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content);
	void TriggerProgress(int32 Sent, int32 Received);
	void RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType);

private:

	int32 HttpSent;
	int32 HttpReceived;
	int32 ContentLength;
};
