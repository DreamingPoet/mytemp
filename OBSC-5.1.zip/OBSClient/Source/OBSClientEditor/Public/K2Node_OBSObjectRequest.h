// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "K2Node_BaseAsyncTask.h"
#include "K2Node_OBSObjectRequest.generated.h"

UCLASS()
class OBSCLIENTEDITOR_API UK2Node_OBSObjectRequest : public UK2Node_BaseAsyncTask
{
	GENERATED_UCLASS_BODY()

	// UEdGraphNode interface
	virtual FText GetTooltipText() const override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	virtual void GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const override;
	// End of UEdGraphNode interface

	// UK2Node interface
	virtual FText GetMenuCategory() const override;
	// End of UK2Node interface
};
