// Copyright 2023 Dreamingpoet All Rights Reserved.
#include "OBSBinaryRequest.h"
#include "OBSClientBPFuncLib.h"

void OBSStaticBinaryProgress(FHttpRequestPtr Request, int32 BytesSent, int32 BytesReceived, FOBSProgress OnProgress)
{
	OnProgress.ExecuteIfBound(BytesSent, BytesReceived);
}

void OBSStaticBinaryResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful, FOBSBinaryResponse OnResponse)
{
	if (!OnResponse.IsBound())
		return;

	if (Response.IsValid() && bWasSuccessful)
	{
		const int32 ResponseCode = Response->GetResponseCode();
		const TArray<FString>& ResponseHeaders = Response->GetAllHeaders();
		const TArray<uint8>& ResponseContent = Response->GetContent();

		TMap<FString, FString> Headers;
		for (int32 i = 0; i < ResponseHeaders.Num(); i++)
		{
			FString Key, Value;
			if (!ResponseHeaders[i].Split(TEXT(": "), &Key, &Value))
				continue;

			if (!Key.IsEmpty())
				Headers.Add(Key, Value);
		}

		OnResponse.Execute(ResponseCode, Headers, ResponseContent);
	}
	else
		OnResponse.Execute(0, TMap<FString, FString>(), TArray<uint8>());
}


bool FOBSBinaryRequest::Process()
{
	HttpRequest->OnRequestProgress().BindStatic(&OBSStaticBinaryProgress, OnProgress);
	HttpRequest->OnProcessRequestComplete().BindStatic(&OBSStaticBinaryResponse, OnResponse);

	return IOBSRequest::Process();
}
