// Copyright 2023 Dreamingpoet All Rights Reserved.

#include "K2Node_OBSObjectRequest.h"
#include "OBSObjectRequestProxy.h"

#define LOCTEXT_NAMESPACE "K2Node_OBS"

UK2Node_OBSObjectRequest::UK2Node_OBSObjectRequest(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UOBSObjectRequestProxy, CreateProxyObject);
	ProxyFactoryClass = UOBSObjectRequestProxy::StaticClass();
	ProxyClass = UOBSObjectRequestProxy::StaticClass();
}

FText UK2Node_OBSObjectRequest::GetTooltipText() const
{
	return LOCTEXT("K2Node_OBSObjectRequest_Tooltip", "Object operations via RESTful request.");
}
FText UK2Node_OBSObjectRequest::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("OBSObjectRequest", "OBS Object Request");
}
void UK2Node_OBSObjectRequest::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
	Super::GetPinHoverText(Pin, HoverTextOut);

	static FName NAME_OnSuccess = FName(TEXT("OnSuccess"));
	static FName NAME_OnProgress = FName(TEXT("OnProgress"));
	static FName NAME_OnFailure = FName(TEXT("OnFailure"));

	if (Pin.PinName == NAME_OnSuccess)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSObjectRequest_OnSuccess_Tooltip", "Called when the OBS request successfully completed, StatusCode == 200.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnProgress)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSObjectRequest_OnProgress_Tooltip", "Called when the OBS request on progress.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
	else if (Pin.PinName == NAME_OnFailure)
	{
		FText ToolTipText = LOCTEXT("K2Node_OBSObjectRequest_OnFailure_Tooltip", "Called when the OBS request failed.");
		HoverTextOut = FString::Printf(TEXT("%s\n%s"), *ToolTipText.ToString(), *HoverTextOut);
	}
}

FText UK2Node_OBSObjectRequest::GetMenuCategory() const
{
	return FText::FromString("OBSClient|Object");
}

#undef LOCTEXT_NAMESPACE
