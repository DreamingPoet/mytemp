// Copyright 2023 Dreamingpoet All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "OBSClientManager.h"
#include "OBSBinaryRequest.h"
#include "OBSBucketRequestProxy.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOBSBucketResponesEvent, const FResponse&, Response);

UCLASS(BlueprintType, meta = (HideThen = true))
class OBSCLIENT_API UOBSBucketRequestProxy : public UObject
{
	GENERATED_UCLASS_BODY()

	UPROPERTY(BlueprintAssignable, Category = "OBSBucket Request")
		FOBSBucketResponesEvent OnSuccess;

	UPROPERTY(BlueprintAssignable, Category = "OBSBucket Request")
		FOBSBucketResponesEvent OnProgress;

	UPROPERTY(BlueprintAssignable, Category = "OBSBucket Request")
		FOBSBucketResponesEvent OnFailure;

	/**
	 * OBSBucket
	 *
	 * @param BucketName
	 * @param CanonicalizedHeaders like: x-amz-acl:private etc.
	 * @param Content default Content-Type: application/xml
	 * 
	 * @return OBSBucketRequestProxy UObject
	 */
	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", AutoCreateRefTerm = "CanonicalizedHeaders, Content, QueryString", AdvancedDisplay = "CanonicalizedHeaders, QueryString, Content, ContentType, UseMD5"), Category = "OBS Library")
		static UOBSBucketRequestProxy* CreateProxyObject(EOBSRequestMethod Method, const FString& BucketName, const TMap<FString, FString>& CanonicalizedHeaders, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType, bool UseMD5);
public:
	UFUNCTION(BlueprintCallable, Category = "OBS Library")
	void Cancel(){ Http.Cancel();}

protected:

	FOBSBinaryRequest Http;

	void TriggerResponse(int32 StatusCode, const TMap<FString, FString>& Headers, const TArray<uint8>& Content);
	void TriggerProgress(int32 Sent, int32 Received);
	void RequestPerform(EOBSRequestMethod Method, const FString& URL, const TMap<FString, FString>& Headers, const TMap<FString, FString>& QueryString, const TArray<uint8>& Content, const FString& ContentType);

private:

	int32 HttpSent;
	int32 HttpReceived;
	int32 ContentLength;
};
